ALTER TABLE  `[#DB_PREFIX#]favorite_tag` ADD INDEX ( `title` );
ALTER TABLE  `[#DB_PREFIX#]favorite_tag` ADD INDEX ( `answer_id` );